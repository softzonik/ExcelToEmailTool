import pandas as pd
import os
import logging

def sort_excel_file_test(input_path, output_path, log_path=None, progress_bar=None):
    try:
        if log_path:
            logging.basicConfig(filename=os.path.join(log_path, 'sort_log.txt'), level=logging.INFO)

        df = pd.read_excel(input_path)

        email_cols = ['Email', 'Email1', 'CompanyEmail']
        mobile_col = 'Mobile Number' if 'Mobile Number' in df.columns else None

        df = df.dropna(subset=email_cols, how='all')  # Keep rows with at least one email

        def get_unique_emails(row):
            email_fields = ["Email", "Email1", "CompanyEmail"]
            emails = set()
            for field in email_fields:
                val = row.get(field, "")
                if pd.notna(val):
                    val = str(val).strip()
                    if val:
                        emails.add(val)
                return list(emails)




        data = []
        for _, row in df.iterrows():
            emails = get_unique_emails(row)
            ptc_name = row.get("ptc_name", "")
            if pd.isna(ptc_name):
                ptc_name = ""
            else:
                ptc_name = str(ptc_name).strip()
            names = ptc_name.split(" ", 1)           

            first = names[0]
            last = names[1] if len(names) > 1 else ""
            entry = {
                "First Name": first,
                "Last Name": last,
                "Email": emails[0] if len(emails) > 0 else "",
                "Email1": emails[1] if len(emails) > 1 else "",
                "CompanyEmail": emails[2] if len(emails) > 2 else "",
            }
            if mobile_col:
                entry["Mobile Number"] = row.get(mobile_col, "")
            data.append(entry)

        out_df = pd.DataFrame(data)
        out_df.to_excel(output_path, index=False)

        if log_path:
            logging.info(f"Sorted file created: {output_path}")

        if progress_bar:
            progress_bar.setValue(100)

    except Exception as e:
        if log_path:
            logging.error(str(e))
        raise


import pandas as pd
import os
import logging

def sort_excel_file(input_path, output_path, log_path=None, progress_bar=None):
    try:
        if log_path:
            logging.basicConfig(filename=os.path.join(log_path, 'sort_log.txt'), level=logging.INFO)

        df = pd.read_excel(input_path)

        email_cols = ['Email', 'Email1', 'CompanyEmail']
        mobile_col = 'Mobile Number' if 'Mobile Number' in df.columns else None

        # Drop rows where all email fields are missing
        df = df.dropna(subset=email_cols, how='all')

        def get_first_valid_email(row):
            for col in email_cols:
                val = row.get(col, "")
                if pd.notna(val):
                    val = str(val).strip()
                    if val:
                        return val
            return ""

        data = []
        for _, row in df.iterrows():
            email = get_first_valid_email(row)
            ptc_name = row.get("ptc_name", "")
            ptc_name = str(ptc_name).strip() if pd.notna(ptc_name) else ""

            names = ptc_name.split(" ", 1)
            first = names[0]
            last = names[1] if len(names) > 1 else ""

            entry = {
                "First Name": first,
                "Last Name": last,
                "Email_id": email,
            }

            if mobile_col:
                entry["Mobile Number"] = row.get(mobile_col, "")
            data.append(entry)

        out_df = pd.DataFrame(data)
        out_df.to_excel(output_path, index=False)

        if log_path:
            logging.info(f"Sorted file created: {output_path}")

        if progress_bar:
            progress_bar.setValue(100)

    except Exception as e:
        if log_path:
            logging.error(str(e))
        raise
