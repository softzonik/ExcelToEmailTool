import os
import smtplib
import time
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from PyQt5.QtCore import QThread, pyqtSignal
import pandas as pd
from openpyxl import load_workbook

ZOHO_SMTP_SERVER = "smtp.zoho.com"
IMAGE_FILE = os.path.join(os.path.dirname(__file__), "../resources/initial.jpg")

SOCIAL_MEDIA_LINKS = {
    "youtube": "https://www.youtube.com/@softzonik2417",
    "whatsapp": "https://wa.me/919764959860",
    "facebook": "https://www.facebook.com/softzonik",
    "linkedin": "https://www.linkedin.com/company/softzonik",
    "instagram": "https://www.instagram.com/softzonik"
}

def attach_image(msg, image_path, cid_name):
    with open(image_path, "rb") as f:
        img = MIMEImage(f.read())
        img.add_header("Content-ID", f"<{cid_name}>")
        img.add_header("Content-Disposition", "inline", filename=cid_name)
        msg.attach(img)

def send_single_mail(to_email, name, sender_email, sender_password):
    try:
        server = smtplib.SMTP_SSL(ZOHO_SMTP_SERVER, 465)
        server.login(sender_email, sender_password)

        msg_root = MIMEMultipart("related")
        msg_root["From"] = sender_email
        msg_root["To"] = to_email
        msg_root["Subject"] = "Business Collaboration Opportunity"
        msg_root.preamble = "This is a multi-part message in MIME format."

        msg_alternative = MIMEMultipart("alternative")
        msg_root.attach(msg_alternative)

        text_content = f"Hi There,\nPlease view this email in an HTML-compatible viewer."
        msg_alternative.attach(MIMEText(text_content, "plain"))

        html_content = f"""
        <html>
        <body style="font-family:Arial, sans-serif; padding:20px;">
            <div style="max-width:600px; margin:auto; background:white; padding:20px; border-radius:10px; box-shadow:0px 0px 10px rgba(0,0,0,0.1);">
                <img src="cid:logo" alt="Business Strategy" style="width:100%; max-height:200px; object-fit:cover; border-radius:5px;">
                <h2 style="color:#333; text-align:center;">Transform Your Business with Cutting-Edge Software Solutions</h2>
                <p>Hi There,</p>
                <p>In today’s digital world, <b>customized software can be the game-changer for your business.</b></p>
                <h3 style="color:#555;">💡 Our Expertise:</h3>
                <ul style="background:#fafafa; padding:15px; border-radius:5px;">
                    <li>✔ Web & Mobile App Development</li>
                    <li>✔ Custom Websites</li>
                    <li>✔ Software Development</li>
                    <li>✔ IT Consulting</li>
                    <li>✔ Cloud Hosting</li>
                    <li>✔ Corporate Training</li>
                </ul>
                <p>🚀 Let’s Build Something Amazing Together!</p>
                <p>📞 <b>Schedule a Free Consultation</b> now!</p>
                <p><a href="mailto:nitin.shinde@softzonik.com" style="color:#ff5722;">📩 Let’s Talk</a></p>
                <p style="background:#ff5722; color:white; padding:10px; text-align:center;">🔥 Limited Projects Onboarded Monthly – Secure Your Spot!</p>
                <p>Best Regards,<br><b>Nitin Shinde</b><br>Founder, SoftZonik<br>📞 +91-9730579284<br>
                🌍 <a href="https://www.softzonik.com" style="color:#ff5722;">www.softzonik.com</a></p>
                <p><b>Connect with us:</b></p>
                <p>
                    <a href="{SOCIAL_MEDIA_LINKS['youtube']}" style="color:#ffcc00;">YouTube</a> |
                    <a href="{SOCIAL_MEDIA_LINKS['whatsapp']}" style="color:#ffcc00;">WhatsApp</a> |
                    <a href="{SOCIAL_MEDIA_LINKS['facebook']}" style="color:#ffcc00;">Facebook</a> |
                    <a href="{SOCIAL_MEDIA_LINKS['linkedin']}" style="color:#ffcc00;">LinkedIn</a> |
                    <a href="{SOCIAL_MEDIA_LINKS['instagram']}" style="color:#ffcc00;">Instagram</a>
                </p>
            </div>
        </body>
        </html>
        """

        msg_alternative.attach(MIMEText(html_content, "html"))

        with open(IMAGE_FILE, "rb") as img_file:
            img = MIMEImage(img_file.read())
            img.add_header("Content-ID", "<logo>")
            img.add_header("Content-Disposition", "inline", filename="logo.jpg")
            msg_root.attach(img)

        server.sendmail(sender_email, to_email, msg_root.as_string())
        server.quit()

        print(f"✅ Sent email to {to_email} (Hi {name})")
        return "Mail Sent on " + datetime.now().strftime("%d-%m-%Y %H:%M:%S")

    except Exception as e:
        print(f"❌ Failed to send email to {to_email}: {e}")
        return f"Failed at {datetime.now().strftime('%H:%M:%S')} - {str(e)}"

class EmailSenderThread(QThread):
    progress_signal = pyqtSignal(int)
    log_signal = pyqtSignal(str)

    def __init__(self, input_file, sender_email, password, start_row, max_count):
        super().__init__()
        self.input_file = input_file
        self.sender_email = sender_email
        self.password = password
        self.start_row = start_row
        self.max_count = max_count

    def run_test(self):
        try:
            TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            df = pd.read_excel(self.input_file)
            df = df.dropna(subset=["Email_id"])
            selected_rows = df.iloc[self.start_row:self.start_row + self.max_count].copy()
            result_list = []

            total = len(selected_rows)
            os.makedirs("logs", exist_ok=True)
            #log_path = os.path.join("logs", "mail_log.txt")
            output_filename = f"output/processed_data_{TIMESTAMP}.xlsx"
            df.iloc[self.start_row:self.start_row + self.max_count].to_excel(output_filename, index=False)

            log_filename = f"logs/mail_log_{TIMESTAMP}.txt"
            with open(log_filename, "a", encoding="utf-8") as log_file:
                for index, row in selected_rows.iterrows():
                    name = row.get("Name", "User")
                    email = row.get("Email_id", "")
                    result = send_single_mail(email, name, self.sender_email, self.password)
                    
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    df.at[index, "Mail_Status"] = result
                    
                    log_entry = f"{timestamp} | {email} | Status: {result}"
                    log_file.write(log_entry + "\n")
                    self.log_signal.emit(log_entry)
                    self.progress_signal.emit(int(((index + 1 - self.start_row) / total) * 100))
                    time.sleep(1)

            # Save updated file with Mail_Status column
            output_dir = "output"
            os.makedirs(output_dir, exist_ok=True)
            input_filename = os.path.basename(self.input_file)
            output_path = os.path.join(output_dir, f"status_{output_filename}")
            df.to_excel(output_path, index=False)

            self.log_signal.emit(f"[DONE] Mail job complete. Output saved to {output_path}")

        except Exception as e:
            error_msg = f"[ERROR] Thread crashed: {str(e)}"
            self.log_signal.emit(error_msg)

    def run(self):
        try:
            TIMESTAMP = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            df = pd.read_excel(self.input_file)
            df = df.dropna(subset=["Email_id"])
            selected_rows = df.iloc[self.start_row:self.start_row + self.max_count].copy()

            total = len(selected_rows)
            os.makedirs("logs", exist_ok=True)
            os.makedirs("output", exist_ok=True)

            log_filename = f"logs/mail_log_{TIMESTAMP}.txt"
            output_filename = f"output/processed_data_{TIMESTAMP}.xlsx"

            with open(log_filename, "a", encoding="utf-8") as log_file:
                for index, row in selected_rows.iterrows():
                    name = row.get("Name", "User")
                    email = row.get("Email_id", "")
                    result = send_single_mail(email, name, self.sender_email, self.password)

                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    df.at[index, "Mail_Status"] = result

                    log_entry = f"{timestamp} | {email} | Status: {result}"
                    log_file.write(log_entry + "\n")
                    self.log_signal.emit(log_entry)
                    self.progress_signal.emit(int(((index + 1 - self.start_row) / total) * 100))
                    time.sleep(1)

            # ✅ Save final DataFrame with Mail_Status column
            df.to_excel(output_filename, index=False)

            self.log_signal.emit(f"[DONE] Mail job complete. Output saved to {output_filename}")

        except Exception as e:
            error_msg = f"[ERROR] Thread crashed: {str(e)}"
            self.log_signal.emit(error_msg)
